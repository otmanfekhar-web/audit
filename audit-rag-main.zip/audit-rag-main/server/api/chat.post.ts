import { AuditDocumentationChatAgent } from "../utils/AuditDocumentationChatAgent";
import { serverSupabaseClient } from "#supabase/server";
import { validateUIMessages } from "ai";

export default defineEventHandler(async (event) => {
  // Validation
  const body = await readBody(event);
  const messages = await validateUIMessages({ messages: body.messages });

  const supabase = await serverSupabaseClient(event);

  const agent = new AuditDocumentationChatAgent(supabase);

  const stream = await agent.run(messages);

  return stream.toUIMessageStreamResponse();
});
