import {
  convertToModelMessages,
  stepCountIs,
  streamText,
  tool,
  type UIMessage,
} from "ai";

import { z } from "zod";
import type { Database } from "~~/types/database.types";
import type { SupabaseClient } from "@supabase/supabase-js";
import { mistral } from "./mistral";
import { voyage } from "./voyage";

export class AuditDocumentationChatAgent {
  supabase: SupabaseClient<Database>;

  constructor(supabase: SupabaseClient<Database>) {
    this.supabase = supabase;
  }

  async run(messages: UIMessage[]) {
    const stream = streamText({
      model: mistral("mistral-small-latest"),
      system: `
          # Identité

          Tu es un assistant qui répond aux question de l'utilisateur au sujet de l'audit financier en France. 

          # Objectif

          Réponds aux question de l'utilisateur au sujet de l'audit financier en France.

          # Instructions

          * Sur la base de la question de l'utilisateur, cherche dans la documentation de l'audit financier en France pour trouver les informations pertinentes. Tu peux faire plusieurs recherches, si besoin.
          * Formule une réponse complète et détaillée en français, en te basant uniquement sur les informations trouvées dans la documentation.
          
          # Contraintes

          * Ta réponse doit uniquement se baser sur les informations trouvées dans la documentation. 
          * Si tu ne trouve pas de réponse dans la documentation, réponds "Je ne sais pas".
          * Répond en français.
        `,
      tools: {
        search_documentation: tool({
          description:
            "Recherche des mots-clés ou une question dans la documentation de l'audit financier en France et retourne les informations pertinentes.Get the current weather in a given location.",
          inputSchema: z.object({
            query: z
              .string()
              .describe(
                "Mots-clés ou question à rechercher dans la documentation"
              ),
          }),

          execute: async ({ query }) => {
            const result = await this._getDocumentation(query);
            return result;
          },
        }),
      },
      stopWhen: stepCountIs(10),
      maxOutputTokens: 1000,
      messages: convertToModelMessages(messages),
    });

    return stream;
  }

  async _getDocumentation(query: string) {
    console.log("Searching documentation for query:", query);

    // Generate embedding for the query
    const embedding = await voyage
      .embed({
        input: [query],
        model: "voyage-3-large",
      })
      .then((res) => res.data?.[0].embedding);

    if (!embedding) {
      throw new Error("Failed to generate embedding for query");
    }

    const data = await this.supabase
      .rpc("hybrid_search", {
        query_text: query,
        // @ts-expect-error Supabase types are wrong for embeddings (vector is translated to string)
        query_embedding: embedding,
        match_count: 5,
      })
      .then((res) => {
        if (res.error) {
          throw res.error;
        }
        return res.data;
      });

    return data
      .map((item) => [item.context, item.content].join("\n\n"))
      .join("\n\n---\n\n");
  }
}
