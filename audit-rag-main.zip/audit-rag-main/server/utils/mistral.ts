import { createMistral } from "@ai-sdk/mistral";

const { mistralApiKey } = useRuntimeConfig();

export const mistral = createMistral({ apiKey: mistralApiKey });
