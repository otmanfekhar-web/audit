import { VoyageAIClient } from "voyageai";

const { voyageApiKey } = useRuntimeConfig();

export const voyage = new VoyageAIClient({ apiKey: voyageApiKey });
