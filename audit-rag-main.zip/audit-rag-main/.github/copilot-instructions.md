# Instructions GitHub Copilot - AUDIT RAG

## À propos du projet

Cette application est un chatbot pour répondre aux questions des utilisateurs sur l'audit financier en France.

### Technologies principales

- **Framework** : Nuxt 4 (Vue.js, TypeScript)
- **UI Framework** : Nuxt UI (basé sur Headless UI + Tailwind CSS), [Documentation Nuxt UI](https://nuxt.com/docs/4.x)
- **Base de données** : Supabase (PostgreSQL + Auth + Storage)
- **Gestionnaire de paquets** : pnpm
- **Testing** : Nuxt Test Utils
- **Linting** : ESLint
- **Gestionnaire de paquets** : pnpm

## Architecture et structure

### Structure des dossiers

```
app/                    # Code source principal de l'application
├── components/         # Composants Vue réutilisables organisés par domaine
├── composables/        # Logique métier réutilisable (useWorkspaces, useProjects, etc.)
├── layouts/           # Layouts de pages
├── pages/             # Routing automatique Nuxt
└── utils/             # Fonctions utilitaires

server/                # API server-side Nuxt
├── api/               # Endpoints API (invitations, etc.)
└── utils/             # Utilitaires server-side

supabase/              # Configuration et migrations Supabase
├── migrations/        # Migrations SQL
├── schemas/          # Schémas de base de données
└── templates/        # Templates d'emails

types/                 # Types TypeScript générés et personnalisés
docs/                  # Documentation du projet
tests/                 # Tests automatisés
```

### Modèle de données principal

Le schema de la base de données est disponible ~/supabase/schemas/\*.sql

- **Users** : Utilisateurs de la plateforme
  TODO: Compléter le modèle de données

## Conventions de développement

### Naming et style

- **Components** : PascalCase (ex: `ProjectGrid.vue`, `RequestCreateModal.vue`)
- **Composables** : camelCase avec préfixe "use" (ex: `useProjects`, `useWorkspace`)
- **Types** : PascalCase pour les interfaces, camelCase pour les propriétés
- **Fichiers** : kebab-case pour les utilitaires, PascalCase pour les composants

### Organisation des composants

- Organiser par domaine métier dans des sous-dossiers
- Utiliser des noms descriptifs incluant le contexte (ex: `Project/CreateModal.vue`)
- Séparer les composants UI génériques des composants métier

### Composables

- Un composable par entité métier principale
- Retourner des objets avec des propriétés nommées explicitement
- Utiliser la réactivité Vue (`ref`, `computed`, `reactive`)
- Gérer les états de chargement et d'erreur

### Base de données et API

- Utiliser les types TypeScript générés depuis Supabase
- Implémenter RLS (Row Level Security) pour la sécurité
- Préférer les composables pour les appels API
- Gérer l'authentification via `@nuxtjs/supabase`

## Fonctionnalités principales

### Fonctionnalité 1

TODO:

### Interface utilisateur

- Design responsive avec Nuxt UI
- Navigation avec fil d'Ariane
- Tableaux de données avec tri et filtrage
- Modales pour les actions CRUD
- Timeline d'activités

## Bonnes pratiques spécifiques

### Sécurité

- Toujours vérifier les permissions via RLS Supabase
- Valider les données côté client ET serveur
- Utiliser l'authentification Supabase pour toutes les routes protégées

### Performance

- Utiliser le lazy loading pour les composants lourds
- Optimiser les requêtes Supabase avec les select() appropriés
- Implémenter la pagination pour les listes importantes

### UX/UI

- Afficher des états de chargement appropriés
- Gérer les erreurs avec des messages utilisateur clairs
- Utiliser des confirmations pour les actions destructives
- Maintenir la cohérence avec le design system Nuxt UI

### Tests

- Tester les composables avec des données mockées
- Tester les politiques RLS Supabase
- Vérifier les permissions et la sécurité

## Patterns récurrents

### Création de modales CRUD

```vue
<template>
  <UModal v-model="isOpen">
    <UCard>
      <template #header>
        <h3>{{ title }}</h3>
      </template>

      <UForm :state="form" @submit="onSubmit">
        <!-- Champs du formulaire -->
      </UForm>
    </UCard>
  </UModal>
</template>
```

### Composables avec état réactif

```typescript
export const useEntity = () => {
  const items = ref([]);
  const loading = ref(false);
  const error = ref(null);

  const fetchItems = async () => {
    loading.value = true;
    try {
      // Logique de récupération
    } catch (err) {
      error.value = err;
    } finally {
      loading.value = false;
    }
  };

  return {
    items: readonly(items),
    loading: readonly(loading),
    error: readonly(error),
    fetchItems,
  };
};
```

### Composables Supabase avec useAsyncData

```typescript
export function useEntity(entityId: string) {
  const supabase = useSupabaseClient<Database>();

  const { data, refresh: fetchEntity } = useAsyncData(
    `entity-${entityId}`,
    async () => {
      const { data, error } = await supabase
        .from("entities")
        .select("*")
        .eq("id", entityId);

      if (error) throw error;
      return data;
    },
    { immediate: false }
  );

  const update = async (
    entity: Database["public"]["Tables"]["entities"]["Update"]
  ) => {
    const { data, error } = await supabase
      .from("entities")
      .update(entity)
      .eq("id", entityId)
      .select();

    if (error) throw error;
    fetchEntity();
    return data;
  };

  return { data, update, fetchEntity };
}
```

### Pattern de notifications Toast

```typescript
const toast = useToast();

// Succès
toast.add({
  title: "Succès",
  description: "Opération réussie",
  color: "success",
});

// Erreur
toast.add({
  title: "Erreur",
  description: "Une erreur s'est produite",
  color: "error",
});
```

### Modales de suppression avec confirmation

```vue
<template>
  <UModal v-model:open="isOpen" title="Supprimer l'élément">
    <slot @click="isOpen = true" />

    <template #body>
      <div class="space-y-4">
        <p class="text-gray-600 dark:text-gray-400">
          Êtes-vous sûr de vouloir supprimer <strong>{{ item.name }}</strong> ?
        </p>

        <UAlert
          icon="i-heroicons-exclamation-triangle"
          color="error"
          variant="soft"
          title="Action irréversible"
          description="Cette action ne peut pas être annulée."
        />
      </div>
    </template>

    <template #footer>
      <div class="flex gap-3 justify-end">
        <UButton color="neutral" variant="ghost" @click="isOpen = false">
          Annuler
        </UButton>
        <UButton color="error" :loading="loading" @click="handleDelete">
          Supprimer
        </UButton>
      </div>
    </template>
  </UModal>
</template>
```

### Structure des formulaires avec UFormField

```vue
<template>
  <div class="space-y-4">
    <UFormField label="Nom" required>
      <UInput v-model="form.name" placeholder="Entrez le nom" />
    </UFormField>

    <UFormField label="Description">
      <UTextarea v-model="form.description" autoresize />
    </UFormField>

    <UFormField label="Statut">
      <USelect
        v-model="form.status"
        :items="[
          { label: 'Actif', value: 'active' },
          { label: 'Inactif', value: 'inactive' },
        ]"
      />
    </UFormField>
  </div>
</template>
```

### Composants Nuxt UI - Points d'attention

#### USelect - Propriété items (pas options)

**⚠️ IMPORTANT** : Nuxt UI utilise la propriété `items` pour USelect, pas `options`.

```vue
<!-- ✅ CORRECT -->
<USelect
  v-model="form.unite"
  :items="unitesOptions"
  placeholder="Sélectionnez une unité"
></USelect>
```

```vue
<!-- ❌ INCORRECT -->
<USelect
  v-model="form.unite"
  :options="unitesOptions"
  placeholder="Sélectionnez une unité"
></USelect>
```

Toujours utiliser `:items` avec USelect pour éviter les erreurs de propriétés inexistantes.

### Endpoints API server-side

```typescript
export default defineEventHandler(async (event) => {
  const { param1, param2 } = await readValidatedBody(
    event,
    z.object({
      param1: z.string(),
      param2: z.string().uuid(),
    }).parse
  );

  const supabase = await serverSupabaseClient<Database>(event);

  // Logique métier
  const { data, error } = await supabase
    .from("table")
    .insert({ param1, param2 });

  if (error) {
    console.error("Error:", error);
    throw createError({ statusCode: 500 });
  }

  return data;
});
```

## Contexte métier

TODO:
