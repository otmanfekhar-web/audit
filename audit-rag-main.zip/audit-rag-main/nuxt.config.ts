// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: "2025-07-15",
  devtools: { enabled: true },
  modules: ["@nuxt/eslint", "@nuxt/ui", "@nuxtjs/supabase", "nuxt-api-shield"],
  css: ["~/assets/css/main.css"],

  supabase: {
    redirect: false,
  },

  runtimeConfig: {
    mistralApiKey: "",
    voyageApiKey: "",
  },

  nuxtApiShield: {
    limit: {
      max: 5,
      duration: 3600,
      ban: 3600,
    },
  },
});
