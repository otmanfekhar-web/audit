create extension vector with schema extensions;

create table documents (
  id bigint primary key generated always as identity,
  metadata jsonb,
  content text,
  -- Contextual Embedding Retrieval
  context text,
  -- Full-Text Search 
  fts tsvector generated always as (to_tsvector('french', content)) stored,
  -- Semantic Search voyage-3-large (1024 dimensions) https://docs.voyageai.com/docs/embeddings
  embedding vector(1024)
);

alter table documents enable row level security;
create policy "Deny all" on documents for all using (false);

-- Create an index for the full-text search
create index on documents using gin(fts);
-- Create an index for the semantic vector search
create index on documents using hnsw (embedding vector_ip_ops);

create or replace function hybrid_search(
  query_text text,
  query_embedding vector(512),
  match_count int,
  full_text_weight float = 1,
  semantic_weight float = 1,
  rrf_k int = 50
)
returns setof documents
security definer
language sql
as $$
with full_text as (
  select
    id,
    -- Note: ts_rank_cd is not indexable but will only rank matches of the where clause
    -- which shouldn't be too big
    row_number() over(order by ts_rank_cd(fts, websearch_to_tsquery(query_text)) desc) as rank_ix
  from
    documents
  where
    fts @@ websearch_to_tsquery(query_text)
  order by rank_ix
  limit least(match_count, 30) * 2
),
semantic as (
  select
    id,
    row_number() over (order by embedding <#> query_embedding) as rank_ix
  from
    documents
  order by rank_ix
  limit least(match_count, 30) * 2
)
select
  documents.*
from
  full_text
  full outer join semantic
    on full_text.id = semantic.id
  join documents
    on coalesce(full_text.id, semantic.id) = documents.id
order by
  coalesce(1.0 / (rrf_k + full_text.rank_ix), 0.0) * full_text_weight +
  coalesce(1.0 / (rrf_k + semantic.rank_ix), 0.0) * semantic_weight
  desc
limit
  least(match_count, 30)
$$;