#!/bin/bash

echo "# supabase stop"
pnpm supabase stop

echo "# supabase db diff --schema=public -f $1"
pnpm supabase db diff --schema=public -f $1

echo "# supabase start"
pnpm supabase start

echo "# supabase db push --local --yes"
pnpm supabase db push --local --yes

# echo "# supabase db reset --local --yes"
# pnpm supabase db reset --local --yes

echo "# supabase gen types typescript --local > ./types/database.types.ts"
pnpm supabase gen types typescript --local > ./types/database.types.ts