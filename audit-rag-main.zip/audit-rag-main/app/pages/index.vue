<script lang="ts" setup>
import { Chat } from "@ai-sdk/vue";

const toast = useToast();

const newMessage = ref("");

const chat = new Chat({
  onError: (error) => {
    chat.messages = [];

    if (error.message.includes('"statusCode": 429')) {
      toast.add({
        title: "Trop de requêtes",
        description:
          "Vous avez envoyé trop de requêtes en peu de temps. Veuillez réessayer plus tard.",
        color: "warning",
      });
      return;
    }

    toast.add({
      title: "Erreur",
      description: "Une erreur est survenue.",
      color: "error",
      duration: 5000,
    });
  },
});

async function handleSubmit() {
  if (newMessage.value.trim().length < 5) {
    return;
  }

  chat.messages = [];

  chat.sendMessage({ text: newMessage.value });

  newMessage.value = "";
}
</script>

<template>
  <div>
    <UContainer class="py-8 max-w-2xl">
      <div class="py-16 max-w-xl mx-auto">
        <h1 class="text-3xl font-bold text-center mb-4">
          Chatbot - Audit Financier
        </h1>

        <p class="text-center text-neutral-500">
          Cette application a été développé par TBMSolutions à des fins de
          démonstration d'un projet personnel.
        </p>
      </div>

      <UInput
        v-model="newMessage"
        placeholder="Posez votre question... Ne pas transmettre de données personnelles ou confidentielles."
        autofocus
        size="lg"
        class="w-full"
        :ui="{ trailing: 'items-end' }"
        @keyup.enter="handleSubmit()"
      />
      <div class="mt-2 flex justify-end">
        <UButton
          label="Poser ma question"
          :disabled="newMessage.trim().length < 5"
          color="neutral"
          :loading="chat.status === 'submitted' || chat.status === 'streaming'"
          @click="handleSubmit()"
        />
      </div>

      <div v-if="chat.messages.length > 0" class="mt-8">
        <UCard :ui="{ body: 'p-4 sm:p-4 whitespace-pre-wrap space-y-4' }">
          <div
            v-for="(m, index) in chat.messages"
            :key="m.id ? m.id : index"
            :class="{ 'font-bold': m.role === 'user' }"
          >
            <span v-if="m.role === 'user'">Votre question : </span>
            <span
              v-for="(part, index) in m.parts"
              :key="`${m.id}-${part.type}-${index}`"
            >
              <span v-if="part.type === 'text'">
                {{ part.text }}
              </span>
            </span>
          </div>
        </UCard>
      </div>

      <div class="mt-4">
        <p class="text-center text-neutral-500 mt-4 text-xs italic">
          Les réponses fournies par le chatbot sont générées par une IA et
          peuvent ne pas être exactes ou appropriées. <br />
          Veuillez vérifier les informations avant de les utiliser.
        </p>
      </div>
    </UContainer>
  </div>
</template>
