<script lang="ts" setup>
import { UButtonGroup } from "#components";
</script>

<template>
  <div class="min-h-screen h-screen min-w-screen">
    <nav
      class="md:fixed relative w-full z-50 transition-all duration-300 bg-white shadow-sm"
    >
      <div class="mx-auto max-w-7xl px-6 lg:px-8">
        <div class="grid grid-cols-3 items-center justify-between gap-4">
          <!-- Logo -->
          <div class="flex items-center py-4">
            <NuxtLink
              class="text-2xl font-bold text-gray-900"
              to="https://tbmsolutions.fr"
              external
            >
              <span class="text-primary-600 font-black">TBM</span>Solutions
            </NuxtLink>
          </div>

          <div class="text-center hidden sm:block">
            <UButtonGroup>
              <UBadge label="Projet" color="neutral" size="lg" />
              <UBadge
                label="Chatbot - Audit Financier"
                variant="subtle"
                color="neutral"
                size="lg"
              />
            </UButtonGroup>
          </div>

          <div class="flex justify-end">
            <!-- Website link -->
            <UButton
              icon="i-uil-globe"
              variant="link"
              color="neutral"
              size="xl"
              to="https://tbmsolutions.fr"
              target="_blank"
            />
            <!-- GitHub Link -->
            <UButton
              icon="i-uil-github"
              variant="link"
              color="neutral"
              size="xl"
              to="https://github.com/TBM-Solutions/audit-rag"
              target="_blank"
            />
          </div>
        </div>
      </div>
    </nav>

    <main class="pt-16 h-full">
      <slot />
    </main>
  </div>
</template>
