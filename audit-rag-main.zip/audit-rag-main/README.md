# 🤖 Chatbot Audit Financier - RAG avec NEP H2A

Un chatbot intelligent spécialisé dans l'audit financier français, construit avec les Normes d'Exercice Professionnel (NEP) publiées par la Haute Autorité de l'Audit (H2A). Ce projet utilise une architecture RAG (Retrieval-Augmented Generation) pour fournir des réponses précises et contextualisées aux questions d'audit.

<img width="1471" height="906" alt="Capture d’écran 2025-09-23 à 14 18 21" src="https://github.com/user-attachments/assets/1868642d-3b29-4b7e-8b83-73233731e5d9" />

Développé par [TBMSolutions](https://tbmsolutions.fr).

## 🎯 Objectif du Projet

Créer un assistant IA qui répond aux questions relatives à l'audit financier en France en s'appuyant uniquement sur les normes officielles NEP de la H2A. Le chatbot permet aux professionnels de l'audit d'obtenir rapidement des informations fiables et réglementaires.

## 🏗️ Architecture Technique

### Stack Technologique

- **Framework** : Nuxt 4 (Vue.js, TypeScript)
- **UI** : Nuxt UI (Headless UI + Tailwind CSS)
- **Base de données** : Supabase (PostgreSQL avec extension vector)
- **LLM** : Mistral AI (`mistral-small-latest`)
- **Embeddings** : Voyage AI (`voyage-3-large` - 1024 dimensions)
- **Text Splitting** : LangChain RecursiveCharacterTextSplitter
- **Gestionnaire de paquets** : pnpm

### Architecture RAG (Agentic Retrieval-Augmented Generation)

```mermaid
graph TD
    A[Question Utilisateur] --> B[Génération Embedding]
    B --> C[Recherche Hybride]
    C --> D[Full-Text Search PostgreSQL]
    C --> E[Semantic Search Vector]
    D --> F[Fusion RRF]
    E --> F
    F --> G[Top 5 Documents]
    G --> H[Contexte + Question]
    H --> I[Mistral AI]
    I --> J[Réponse Générée]
```

## 🔄 Pipeline d'Ingestion des Documents

### 1. Collecte des Documents

- **Source** : 38 documents NEP au format Markdown
- **Localisation** : `bin/documents-ingestion/documents/`
- **Format** : Documents officiels H2A convertis en Markdown

### 2. Traitement et Segmentation

```typescript
// Configuration du text splitter
const textSplitter = RecursiveCharacterTextSplitter.fromLanguage("markdown", {
  chunkSize: 2000, // Taille optimale pour la cohérence
  chunkOverlap: 200, // Chevauchement pour éviter la perte de contexte
});
```

### 3. Génération de Contexte Enrichi

Pour chaque chunk, un contexte additionnel est généré via Mistral AI :

```typescript
const prompt = `<document>${document}</document>
<chunk>${chunk}</chunk>
Give a short succinct context to situate this chunk within the overall document for the purposes of improving search retrieval of the chunk.`;
```

### 4. Génération d'Embeddings

- **Modèle** : Voyage AI `voyage-3-large`
- **Dimensions** : 1024
- **Entrée** : Contexte + Contenu du chunk
- **Cache** : Système de cache local pour éviter les re-calculs

### 5. Stockage en Base de Données

Structure de la table `documents` :

```sql
CREATE TABLE documents (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  metadata JSONB,
  content TEXT,              -- Contenu original du chunk
  context TEXT,              -- Contexte généré par IA
  fts TSVECTOR,             -- Index full-text search français
  embedding VECTOR(1024)     -- Embedding sémantique
);
```

## 🔍 Système de Recherche Hybride

### Algorithme RRF (Reciprocal Rank Fusion)

La recherche combine deux approches :

1. **Full-Text Search** : Recherche textuelle PostgreSQL avec index GIN
2. **Semantic Search** : Recherche vectorielle avec index HNSW

```sql
-- Fonction de recherche hybride avec fusion RRF
CREATE OR REPLACE FUNCTION hybrid_search(
  query_text TEXT,
  query_embedding VECTOR(512),
  match_count INT,
  full_text_weight FLOAT = 1,
  semantic_weight FLOAT = 1,
  rrf_k INT = 50
)
```

### Scoring Final

```
Score = (1/(rrf_k + rang_textuel)) * poids_textuel +
        (1/(rrf_k + rang_sémantique)) * poids_sémantique
```

## 🤖 Agent Conversationnel

### Architecture de l'Agent

```typescript
export class AuditDocumentationChatAgent {
  async run(messages: UIMessage[]) {
    return streamText({
      model: mistral("mistral-small-latest"),
      system: `Tu es un assistant spécialisé en audit financier français...`,
      tools: { search_documentation },
      stopWhen: stepCountIs(10),
      maxOutputTokens: 1000,
    });
  }
}
```

### Fonctionnement

1. **Question utilisateur** → Conversion en embedding
2. **Recherche hybride** → Top 5 documents pertinents
3. **Contexte enrichi** → Injection dans le prompt système
4. **Génération** → Réponse basée uniquement sur la documentation
5. **Streaming** → Affichage en temps réel

## 🛡️ Sécurité et Limitations

### Rate Limiting

Mise en place d'un rate limiting

### Contraintes de Réponse

- **Source unique** : Uniquement basé sur les documents NEP
- **Langue** : Réponses en français
- **Fallback** : "Je ne sais pas" si information non trouvée
- **Transparence** : Pas de hallucination, uniquement les sources

## 🚀 Installation et Déploiement

### Prérequis

```bash
# Node.js 22+
# pnpm
# Supabase CLI
```

### Variables d'Environnement

```env
MISTRAL_API_KEY=your_mistral_key
VOYAGE_API_KEY=your_voyage_key
SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_supabase_anon_key
```

### Installation

```bash
# Installation des dépendances
pnpm install

# Configuration Supabase
supabase start
supabase db push

# Ingestion des documents (première fois)
pnpm tsx bin/documents-ingestion/main.ts

# Lancement du serveur de développement
pnpm dev
```

### Déploiement

```bash
# Construction pour la production
pnpm build

# Preview local
pnpm preview
```

## 📊 Métriques et Performance

### Base de Données

- **38 documents NEP** traités
- **~500-1000 chunks** générés (selon la taille des documents)
- **Index HNSW** pour la recherche vectorielle rapide
- **Index GIN** pour la recherche textuelle

### Réponse

- **Latence moyenne** : 2-4 secondes
- **Top-K** : 5 documents les plus pertinents
- **Streaming** : Affichage progressif de la réponse

## 🤝 Contribution

Ce projet est développé par **TBM Solutions** à des fins de démonstration.

## ⚠️ Avertissements

- Les réponses sont générées par IA et peuvent contenir des erreurs
- Toujours vérifier les informations avant utilisation professionnelle
- Ne pas transmettre de données personnelles ou confidentielles
- Usage limité par rate limiting pour éviter les abus

## 📝 Licence

Projet personnel de démonstration - TBM Solutions 2025
